import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DOCUMENTS_DIR = os.path.join(BASE_DIR, "data", "docs")
STORAGE_DIR = os.path.join(BASE_DIR, "data", "faiss_index")

EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
LLM_MODEL = "Qwen/Qwen2.5-3B-Instruct"

CHUNK_SIZE = 900
CHUNK_OVERLAP = 150
TOP_K = 3
MAX_NEW_TOKENS = 512
