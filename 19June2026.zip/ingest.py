from app.rag import build_index
from config import DOCUMENTS_DIR, STORAGE_DIR


def main():
    print(f"Citesc documentele din: {DOCUMENTS_DIR}")
    print(f"Construiesc indexul FAISS în: {STORAGE_DIR}")

    result = build_index()

    print("Index creat cu succes.")
    print(f"Documente indexate: {result['documents']}")
    print(f"Fragmente generate: {result['chunks']}")
    print("Fișiere generate: index.faiss și metadata.pkl")


if __name__ == "__main__":
    main()
