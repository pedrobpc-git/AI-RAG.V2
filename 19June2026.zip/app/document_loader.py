import os
from pypdf import PdfReader
from docx import Document


SUPPORTED_EXTENSIONS = {".txt", ".md", ".pdf", ".docx"}


def read_txt(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def read_pdf(path: str) -> str:
    reader = PdfReader(path)
    pages = []
    for page in reader.pages:
        text = page.extract_text()
        if text:
            pages.append(text)
    return "\n".join(pages)


def read_docx(path: str) -> str:
    doc = Document(path)
    return "\n".join(p.text for p in doc.paragraphs if p.text.strip())


def load_documents(documents_dir: str):
    documents = []

    if not os.path.isdir(documents_dir):
        os.makedirs(documents_dir, exist_ok=True)
        return documents

    for root, _, files in os.walk(documents_dir):
        for filename in files:
            path = os.path.join(root, filename)
            ext = os.path.splitext(filename.lower())[1]

            if ext not in SUPPORTED_EXTENSIONS:
                continue

            try:
                if ext in {".txt", ".md"}:
                    text = read_txt(path)
                elif ext == ".pdf":
                    text = read_pdf(path)
                elif ext == ".docx":
                    text = read_docx(path)
                else:
                    continue
            except Exception as exc:
                print(f"Nu am putut citi {path}: {exc}")
                continue

            if text.strip():
                documents.append({"source": path, "text": text})

    return documents
