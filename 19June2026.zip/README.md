# AI-RAG Local Chat

RAG local cu Flask, FAISS, Sentence Transformers si Qwen2.5-3B-Instruct.

Aplicatia permite:

- chat web local;
- istoric conversatie in browser;
- upload documente din UI;
- reindexare din UI;
- cautare semantica in documente locale;
- raspunsuri generate local cu Qwen2.5-3B-Instruct;
- afisare surse si preview din documentele folosite.

Datele si documentele raman pe masina locala.

---

## 1. Cerinte initiale

Laptopul trebuie sa aiba instalat doar Python.

Recomandat:

```bash
python --version
```

sau:

```bash
python3 --version
```

Versiune recomandata:

```text
Python 3.11+
```

Pentru Qwen2.5-3B este recomandat:

```text
RAM minim: 8 GB
RAM recomandat: 16 GB
```

La prima rulare, modelul Qwen poate fi descarcat automat de pe Hugging Face, deci este necesar acces la internet pentru primul download.

---

## 2. Dezarhivare proiect

```bash
unzip AI-RAG-chat-final.zip
cd AI-RAG
```

Daca ai primit alta denumire pentru arhiva, foloseste numele respectiv.

---

## 3. Creare mediu virtual

### Windows - CMD

```cmd
python -m venv .venv
.venv\Scripts\activate
```

### Windows - PowerShell

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

Daca PowerShell blocheaza activarea mediului virtual, ruleaza:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

Apoi incearca din nou:

```powershell
.venv\Scripts\Activate.ps1
```

### Linux / macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Dupa activare trebuie sa vezi ceva de forma:

```text
(.venv)
```

in prompt.

---

## 4. Actualizare pip

```bash
python -m pip install --upgrade pip
```

---

## 5. Instalare dependinte

### Varianta recomandata - folosind requirements.txt

```bash
pip install -r requirements.txt
```

### Varianta explicita - comenzile complete

Daca vrei sa instalezi manual toate dependintele, ruleaza:

```bash
pip install torch transformers accelerate
pip install sentence-transformers
pip install faiss-cpu
pip install flask
pip install pypdf python-docx
pip install numpy
```

Sau intr-o singura comanda:

```bash
pip install torch transformers accelerate sentence-transformers faiss-cpu flask pypdf python-docx numpy
```

---

## 6. Verificare dependinte instalate

```bash
pip list
```

Trebuie sa existe cel putin:

```text
torch
transformers
accelerate
sentence-transformers
faiss-cpu
flask
pypdf
python-docx
numpy
```

---

## 7. Structura proiectului

```text
AI-RAG/
|
|-- main.py
|-- ingest.py
|-- config.py
|-- requirements.txt
|-- README.md
|
|-- app/
|   |-- __init__.py
|   |-- chunker.py
|   |-- document_loader.py
|   |-- llm.py
|   |-- rag.py
|   |-- vector_store.py
|
|-- templates/
|   |-- index.html
|
|-- static/
|   |-- app.js
|   |-- style.css
|
|-- data/
|   |-- docs/
|   |-- faiss_index/
```

---

## 8. Modele folosite

### LLM local

```text
Qwen/Qwen2.5-3B-Instruct
```

Este folosit pentru generarea raspunsurilor.

### Embeddings

```text
sentence-transformers/all-MiniLM-L6-v2
```

Este folosit pentru vectorizarea documentelor si intrebarilor.

### Vector DB local

```text
FAISS
```

Indexul este salvat local in:

```text
data/faiss_index
```

---

## 9. Adaugare documente

Copiaza documentele in:

```text
data/docs
```

Exemplu:

```text
data/docs/onboarding.pdf
data/docs/procedura.docx
data/docs/notite.txt
data/docs/arhitectura.md
```

Formate suportate:

```text
.pdf
.docx
.txt
.md
```

Documentele pot fi adaugate si din Web UI, folosind butonul de upload.

---

## 10. Ingestie documente

Ruleaza:

```bash
python ingest.py
```

Procesul de ingestie face urmatoarele:

1. citeste documentele din `data/docs`;
2. extrage textul;
3. imparte textul in chunk-uri;
4. genereaza embeddings;
5. creeaza indexul FAISS;
6. salveaza metadata pentru surse.

La final trebuie sa fie generate:

```text
data/faiss_index/index.faiss
data/faiss_index/metadata.pkl
```

---

## 11. Verificare index FAISS

Linux / macOS:

```bash
ls -la data/faiss_index
```

Windows CMD:

```cmd
dir data\faiss_index
```

Trebuie sa vezi:

```text
index.faiss
metadata.pkl
```

Daca aceste fisiere nu exista, ruleaza din nou:

```bash
python ingest.py
```

---

## 12. Pornire aplicatie

```bash
python main.py
```

Aplicatia porneste pe:

```text
http://localhost:5000
```

Deschide aceasta adresa in browser.

---

## 13. Flow complet de rulare

De la zero, comenzile sunt:

### Windows CMD

```cmd
cd AI-RAG
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
mkdir data\docs
mkdir data\faiss_index
python ingest.py
python main.py
```

### Windows PowerShell

```powershell
cd AI-RAG
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
mkdir data\docs
mkdir data\faiss_index
python ingest.py
python main.py
```

### Linux / macOS

```bash
cd AI-RAG
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
mkdir -p data/docs
mkdir -p data/faiss_index
python ingest.py
python main.py
```

Apoi deschide:

```text
http://localhost:5000
```

---

## 14. Flow aplicatie

```text
1. Pui documente in data/docs sau le incarci din UI.
2. Rulezi python ingest.py sau apesi Reindex din UI.
3. Aplicatia creeaza index.faiss si metadata.pkl.
4. Pornesti aplicatia cu python main.py.
5. Deschizi http://localhost:5000.
6. Pui intrebari in chat.
7. Sistemul cauta in FAISS cele mai relevante fragmente.
8. Fragmentele sunt trimise catre Qwen2.5-3B-Instruct.
9. Raspunsul este afisat in chat impreuna cu sursele.
```

---

## 15. Reindexare dupa documente noi

Dupa ce adaugi, stergi sau modifici documente:

```bash
python ingest.py
```

Sau foloseste butonul de reindexare din UI.

---

## 16. Stergere index

Daca vrei sa reconstruiesti indexul de la zero:

### Linux / macOS

```bash
rm -rf data/faiss_index/*
python ingest.py
```

### Windows CMD

```cmd
del /q data\faiss_index\*
python ingest.py
```

### Windows PowerShell

```powershell
Remove-Item data\faiss_index\* -Force
python ingest.py
```

---

## 17. Probleme frecvente

### Eroare: Indexul nu exista

Mesaj:

```text
Indexul nu exista. Ruleaza mai intai: python ingest.py
```

Rezolvare:

```bash
python ingest.py
```

Verifica apoi:

```text
data/faiss_index/index.faiss
data/faiss_index/metadata.pkl
```

---

### Nu sunt gasite documente

Mesaj posibil:

```text
Nu am gasit documente suportate in folderul data/docs
```

Rezolvare:

1. verifica daca exista fisiere in `data/docs`;
2. verifica extensiile: `.pdf`, `.docx`, `.txt`, `.md`;
3. ruleaza din nou `python ingest.py`.

---

### Modelul se incarca greu

La prima intrebare, Qwen2.5-3B poate dura pana se descarca si se incarca in memorie.

Dupa primul download, modelul ramane in cache-ul local Hugging Face.

---

### Memorie insuficienta

Daca laptopul are 8 GB RAM, modelul poate merge greu.

Optiuni:

1. inchide aplicatii consumatoare de memorie;
2. foloseste documente mai putine pentru test;
3. foloseste un model mai mic in `config.py`, daca este necesar.

---

## 18. Configurare

Fisier:

```text
config.py
```

Parametri importanti:

```python
DOCUMENTS_DIR = "data/docs"
STORAGE_DIR = "data/faiss_index"
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
LLM_MODEL = "Qwen/Qwen2.5-3B-Instruct"
CHUNK_SIZE = 900
CHUNK_OVERLAP = 150
TOP_K = 5
```

---

## 19. Ce nu trebuie pus in Git

Fisierul `.gitignore` exclude:

```text
.venv/
__pycache__/
data/faiss_index/
*.pyc
```

Recomandare: nu urca documente interne sau indexul FAISS intr-un repository public.

---

## 20. Pornire rapida dupa prima instalare

Dupa ce totul a fost instalat o data:

### Windows

```cmd
cd AI-RAG
.venv\Scripts\activate
python main.py
```

### Linux / macOS

```bash
cd AI-RAG
source .venv/bin/activate
python main.py
```

Apoi:

```text
http://localhost:5000
```

---

# Troubleshooting: Tensor on device cpu is not on the expected device meta

Dacă apare eroarea:

```text
RuntimeError: Tensor on device cpu is not on the expected device meta!
```

înseamnă că modelul a fost încărcat cu mecanism de tip `device_map="auto"` / `meta device`, iar laptopul nu are resursele sau configurația potrivită pentru acel mod.

Versiunea curentă a proiectului încarcă modelul explicit pe CPU sau CUDA și nu mai folosește `device_map="auto"`.

După update, repornește aplicația:

```bash
python main.py
```

Dacă problema persistă, șterge cache-ul Python:

```bash
find . -name "__pycache__" -type d -exec rm -rf {} +
```

Pe Windows, șterge manual directoarele `__pycache__` sau rulează:

```cmd
for /d /r . %d in (__pycache__) do @if exist "%d" rd /s /q "%d"
```
