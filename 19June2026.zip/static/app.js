const chat = document.getElementById('chat');
const form = document.getElementById('askForm');
const questionInput = document.getElementById('question');
const statusBox = document.getElementById('status');
const uploadBtn = document.getElementById('uploadBtn');
const reindexBtn = document.getElementById('reindexBtn');
const refreshBtn = document.getElementById('refreshBtn');
const clearChatBtn = document.getElementById('clearChat');
const filesInput = document.getElementById('files');

let history = JSON.parse(localStorage.getItem('rag_chat_history') || '[]');
renderHistory();
refreshStatus();

function saveHistory() {
  localStorage.setItem('rag_chat_history', JSON.stringify(history.slice(-20)));
}

function addMessage(role, content, sources = []) {
  history.push({ role, content, sources });
  saveHistory();
  renderHistory();
}

function renderHistory() {
  chat.innerHTML = '';
  for (const item of history) {
    appendMessageElement(item.role, item.content, item.sources || []);
  }
  chat.scrollTop = chat.scrollHeight;
}

function appendMessageElement(role, content, sources = []) {
  const div = document.createElement('div');
  div.className = `message ${role === 'user' ? 'user' : 'bot'}`;
  div.textContent = content;

  if (sources.length) {
    div.appendChild(renderSources(sources));
  }

  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
  return div;
}

function renderSources(sources) {
  const wrapper = document.createElement('div');
  wrapper.className = 'sources';
  const title = document.createElement('div');
  title.textContent = 'Surse folosite:';
  wrapper.appendChild(title);

  for (const source of sources) {
    const card = document.createElement('div');
    card.className = 'source-card';
    const sourceTitle = document.createElement('div');
    sourceTitle.className = 'source-title';
    sourceTitle.textContent = `[Sursa ${source.id}] ${source.file || source.source} | chunk ${source.chunk_id} | score ${source.score}`;
    const preview = document.createElement('div');
    preview.className = 'source-preview';
    preview.textContent = source.preview || '';
    card.appendChild(sourceTitle);
    card.appendChild(preview);
    wrapper.appendChild(card);
  }
  return wrapper;
}

function getPromptHistory() {
  return history
    .filter(item => item.role === 'user' || item.role === 'assistant')
    .map(item => ({ role: item.role, content: item.content }))
    .slice(-8);
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const question = questionInput.value.trim();
  if (!question) return;

  questionInput.value = '';
  addMessage('user', question);

  const botDiv = appendMessageElement('assistant', '');
  let answer = '';
  let sources = [];

  try {
    const response = await fetch('/ask-stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, history: getPromptHistory() })
    });

    if (!response.ok || !response.body) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.error || response.statusText);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const events = buffer.split('\n\n');
      buffer = events.pop();

      for (const rawEvent of events) {
        const lines = rawEvent.split('\n');
        const eventLine = lines.find(line => line.startsWith('event: '));
        const dataLine = lines.find(line => line.startsWith('data: '));
        if (!eventLine || !dataLine) continue;

        const eventType = eventLine.slice(7).trim();
        const data = JSON.parse(dataLine.slice(6));

        if (eventType === 'sources') {
          sources = data;
        } else if (eventType === 'token') {
          answer += data;
          botDiv.textContent = answer;
          chat.scrollTop = chat.scrollHeight;
        } else if (eventType === 'error') {
          throw new Error(data);
        }
      }
    }

    if (!answer.trim()) {
      answer = 'Nu am primit un răspuns de la model.';
      botDiv.textContent = answer;
    }

    if (sources.length) {
      botDiv.appendChild(renderSources(sources));
    }
    history.push({ role: 'assistant', content: answer, sources });
    saveHistory();
  } catch (error) {
    botDiv.classList.add('error');
    botDiv.textContent = `Eroare: ${error.message}`;
  }
});

uploadBtn.addEventListener('click', async () => {
  if (!filesInput.files.length) {
    statusBox.textContent = 'Alege unul sau mai multe fișiere înainte de upload.';
    return;
  }

  const formData = new FormData();
  for (const file of filesInput.files) {
    formData.append('files', file);
  }

  uploadBtn.disabled = true;
  statusBox.textContent = 'Se încarcă fișierele...';

  try {
    const response = await fetch('/upload', { method: 'POST', body: formData });
    const data = await response.json();
    if (!response.ok || data.error) throw new Error(data.error || response.statusText);
    statusBox.textContent = `Upload finalizat. Salvate: ${data.saved.join(', ') || '-'}; ignorate: ${data.skipped.join(', ') || '-'}. Rulează reindexarea.`;
    filesInput.value = '';
    refreshStatus();
  } catch (error) {
    statusBox.textContent = `Eroare upload: ${error.message}`;
  } finally {
    uploadBtn.disabled = false;
  }
});

reindexBtn.addEventListener('click', async () => {
  reindexBtn.disabled = true;
  statusBox.textContent = 'Se reconstruiește indexul FAISS...';

  try {
    const response = await fetch('/reindex', { method: 'POST' });
    const data = await response.json();
    if (!response.ok || data.error) throw new Error(data.error || response.statusText);
    statusBox.textContent = `${data.message}\nDocumente: ${data.documents}\nFragmente: ${data.chunks}\nIndex: ${data.storage_dir}`;
  } catch (error) {
    statusBox.textContent = `Eroare reindexare: ${error.message}`;
  } finally {
    reindexBtn.disabled = false;
  }
});

refreshBtn.addEventListener('click', refreshStatus);

clearChatBtn.addEventListener('click', () => {
  history = [];
  saveHistory();
  renderHistory();
});

async function refreshStatus() {
  try {
    const response = await fetch('/status');
    const data = await response.json();
    statusBox.textContent = `Index existent: ${data.index_exists ? 'DA' : 'NU'}\nDocumente (${data.documents.length}): ${data.documents.join(', ') || '-'}\nDocs dir: ${data.documents_dir}\nIndex dir: ${data.storage_dir}`;
  } catch (error) {
    statusBox.textContent = `Nu pot citi statusul: ${error.message}`;
  }
}
