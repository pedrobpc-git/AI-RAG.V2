import json
import os
from werkzeug.utils import secure_filename
from flask import Flask, Response, jsonify, render_template, request, stream_with_context

from app.llm import ask_local_qwen, stream_local_qwen
from app.rag import build_index
from app.vector_store import VectorStore
from config import DOCUMENTS_DIR, EMBEDDING_MODEL, LLM_MODEL, MAX_NEW_TOKENS, STORAGE_DIR, TOP_K


ALLOWED_EXTENSIONS = {".txt", ".md", ".pdf", ".docx"}

flask_app = Flask(__name__)
flask_app.config["MAX_CONTENT_LENGTH"] = 64 * 1024 * 1024
store = VectorStore(EMBEDDING_MODEL, STORAGE_DIR)


def _format_sources(contexts):
    sources = []
    for idx, ctx in enumerate(contexts):
        text = ctx.get("text", "")
        sources.append({
            "id": idx + 1,
            "source": ctx.get("source", ""),
            "file": os.path.basename(ctx.get("source", "")),
            "score": round(float(ctx.get("score", 0)), 3),
            "chunk_id": ctx.get("chunk_id", "-"),
            "preview": text[:600].replace("\n", " ").strip(),
        })
    return sources


def _allowed_file(filename):
    return os.path.splitext(filename.lower())[1] in ALLOWED_EXTENSIONS


@flask_app.route("/")
def index():
    return render_template("index.html")


@flask_app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json(force=True)
    question = data.get("question", "").strip()
    history = data.get("history", [])

    if not question:
        return jsonify({"error": "Întrebarea este goală."}), 400

    try:
        contexts = store.search(question, top_k=TOP_K)
        answer = ask_local_qwen(question, contexts, LLM_MODEL, MAX_NEW_TOKENS, history=history)
        return jsonify({"answer": answer, "sources": _format_sources(contexts)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@flask_app.route("/ask-stream", methods=["POST"])
def ask_stream():
    data = request.get_json(force=True)
    question = data.get("question", "").strip()
    history = data.get("history", [])

    if not question:
        return jsonify({"error": "Întrebarea este goală."}), 400

    def generate():
        try:
            contexts = store.search(question, top_k=TOP_K)
            yield f"event: sources\ndata: {json.dumps(_format_sources(contexts), ensure_ascii=False)}\n\n"
            for token in stream_local_qwen(question, contexts, LLM_MODEL, MAX_NEW_TOKENS, history=history):
                yield f"event: token\ndata: {json.dumps(token, ensure_ascii=False)}\n\n"
            yield "event: done\ndata: {}\n\n"
        except Exception as exc:
            yield f"event: error\ndata: {json.dumps(str(exc), ensure_ascii=False)}\n\n"

    return Response(stream_with_context(generate()), mimetype="text/event-stream")


@flask_app.route("/upload", methods=["POST"])
def upload():
    if "files" not in request.files:
        return jsonify({"error": "Nu ai trimis niciun fișier."}), 400

    files = request.files.getlist("files")
    saved = []
    skipped = []
    os.makedirs(DOCUMENTS_DIR, exist_ok=True)

    for file in files:
        if not file.filename:
            continue
        filename = secure_filename(file.filename)
        if not _allowed_file(filename):
            skipped.append(file.filename)
            continue
        path = os.path.join(DOCUMENTS_DIR, filename)
        file.save(path)
        saved.append(filename)

    return jsonify({"saved": saved, "skipped": skipped})


@flask_app.route("/reindex", methods=["POST"])
def reindex():
    global store
    try:
        result = build_index()
        store = VectorStore(EMBEDDING_MODEL, STORAGE_DIR)
        store.load()
        return jsonify({"message": "Index recreat cu succes.", **result})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@flask_app.route("/status")
def status():
    index_path = os.path.join(STORAGE_DIR, "index.faiss")
    metadata_path = os.path.join(STORAGE_DIR, "metadata.pkl")
    docs = []
    if os.path.isdir(DOCUMENTS_DIR):
        for root, _, files in os.walk(DOCUMENTS_DIR):
            for filename in files:
                if _allowed_file(filename):
                    docs.append(os.path.relpath(os.path.join(root, filename), DOCUMENTS_DIR))

    return jsonify({
        "documents_dir": DOCUMENTS_DIR,
        "storage_dir": STORAGE_DIR,
        "index_exists": os.path.exists(index_path) and os.path.exists(metadata_path),
        "documents": sorted(docs),
    })


if __name__ == "__main__":
    flask_app.run(host="0.0.0.0", port=5000, debug=True, threaded=True)
